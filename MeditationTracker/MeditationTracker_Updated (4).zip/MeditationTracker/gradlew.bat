@echo off
gradle assembleDebug %*
